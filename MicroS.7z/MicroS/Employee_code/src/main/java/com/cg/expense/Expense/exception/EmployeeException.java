package com.cg.expense.Expense.exception;

public class EmployeeException extends RuntimeException{
	public EmployeeException(String exception) {
	    super(exception);
	  }

}
